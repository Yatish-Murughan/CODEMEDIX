"""Web server: python app.py  ->  http://127.0.0.1:5000  (API keys stay on the server, read from .env)"""
import os

from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory

load_dotenv()
from main import run_agent  # noqa: E402

app = Flask(__name__, static_folder="static")


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.post("/api/ask")
def ask():
    query = ((request.get_json(silent=True) or {}).get("query") or "").strip()
    if not query:
        return jsonify({"error": "Please enter a question."}), 400
    try:
        answer, trace = run_agent(query[:1000], dry_run=bool(os.environ.get("AGENTX_DRY_RUN")))
        return jsonify({"answer": answer, "trace": trace})
    except Exception as e:  # always return valid JSON
        return jsonify({"answer": f"Agent error: {type(e).__name__}: {e}", "trace": []}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))

"""Medical tools: dose calculation, interaction checking, red-flag triage. Educational only, not medical advice."""
import csv
import os
import re

import config
from tools import Tool

DISCLAIMER = "Educational decision support only; confirm with a clinician or pharmacist."


def _norm(s):
    return re.sub(r"\s+", "_", str(s).strip().lower())


def _read_csv(filename):
    path = os.path.join(config.DATA_DIR, filename)
    if not os.path.exists(path):
        raise FileNotFoundError(f"{filename} not found in data folder. Use list_files first.")
    with open(path, encoding="utf-8", errors="ignore", newline="") as f:
        return list(csv.DictReader(f))


class DoseCalculator(Tool):
    name = "dose_calculator"
    description = ("Weight-based dose maths with safety caps. Looks up per-kg dose, max single/daily dose in "
                   "medications.csv unless you pass them explicitly. Flags values over the daily maximum.")
    args_doc = ('{"drug": "paracetamol", "weight_kg": 25, "age_years": 8, "mg_per_kg": null, '
                '"max_single_mg": null, "max_daily_mg": null, "doses_per_day": null, "proposed_daily_mg": null}')

    def execute(self, drug, weight_kg, age_years=None, mg_per_kg=None, max_single_mg=None,
                max_daily_mg=None, doses_per_day=None, proposed_daily_mg=None):
        weight = float(weight_kg)
        if weight <= 0:
            raise ValueError("weight_kg must be positive")
        ref = {}
        try:
            ref = next((r for r in _read_csv("medications.csv") if _norm(r.get("drug", "")) == _norm(drug)), {})
        except FileNotFoundError:
            pass

        def pick(given, key):
            if given not in (None, ""):
                return float(given)
            try:
                return float(ref.get(key) or 0) or None
            except ValueError:
                return None

        per_kg, single_cap = pick(mg_per_kg, "mg_per_kg_per_dose"), pick(max_single_mg, "max_single_mg")
        daily_cap, n = pick(max_daily_mg, "max_daily_mg"), int(pick(doses_per_day, "doses_per_day") or 1)
        if not ref and per_kg is None and single_cap is None:
            return f"ERROR: no reference data for '{drug}'. Pass mg_per_kg / max_single_mg / max_daily_mg explicitly."
        warnings = []
        if _norm(drug) == "aspirin" and age_years is not None and float(age_years) < 16:
            warnings.append("Aspirin is not recommended under 16 years (Reye syndrome risk).")
        dose = per_kg * weight if per_kg else (single_cap or 0)
        if single_cap and dose > single_cap:
            dose, _ = single_cap, warnings.append(f"Dose capped at max single dose {single_cap:g} mg.")
        daily = dose * n
        if daily_cap and daily > daily_cap:
            daily, _ = daily_cap, warnings.append(f"Daily total capped at maximum {daily_cap:g} mg.")
        if proposed_daily_mg not in (None, "") and daily_cap and float(proposed_daily_mg) > daily_cap:
            warnings.append(f"UNSAFE: proposed {float(proposed_daily_mg):g} mg/day exceeds maximum {daily_cap:g} mg/day.")
        if ref.get("notes"):
            warnings.append(f"Note: {ref['notes']}")
        return {"drug": drug, "weight_kg": weight, "single_dose_mg": round(dose, 1), "doses_per_day": n,
                "daily_total_mg": round(daily, 1), "warnings": warnings, "disclaimer": DISCLAIMER}


class InteractionChecker(Tool):
    name = "interaction_checker"
    description = ("Check every pair among a list of drugs against interactions.csv, and optionally check the drugs "
                   "against known allergies. Returns interactions sorted by severity.")
    args_doc = '{"drugs": ["warfarin", "ibuprofen"], "allergies": ["penicillin"]}'

    ORDER = {"major": 0, "moderate": 1, "minor": 2}

    def execute(self, drugs, allergies=None):
        if isinstance(drugs, str):
            drugs = re.split(r"[;,]", drugs)
        if isinstance(allergies, str):
            allergies = re.split(r"[;,]", allergies)
        drugs = [_norm(d) for d in drugs if _norm(d) not in ("", "none")]
        allergies = [_norm(a) for a in (allergies or []) if _norm(a) not in ("", "none")]
        table = _read_csv("interactions.csv")
        found = []
        for i, a in enumerate(drugs):
            for b in drugs[i + 1:]:
                for r in table:
                    if {_norm(r["drug_a"]), _norm(r["drug_b"])} == {a, b}:
                        found.append({"pair": [a, b], "severity": r["severity"], "effect": r["effect"]})
        found.sort(key=lambda r: self.ORDER.get(r["severity"], 3))
        allergy_hits = [f"{d} may conflict with {al} allergy" for d in drugs for al in allergies
                        if al in d or (al == "penicillin" and d in ("amoxicillin", "ampicillin"))]
        return {"interactions": found, "allergy_flags": allergy_hits,
                "note": "No listed interaction does not prove safety." if not found else DISCLAIMER}


class SymptomTriage(Tool):
    name = "symptom_triage"
    description = "Rule-based red-flag screen of symptom text and age. Returns urgency: emergency / urgent / routine."
    args_doc = '{"symptoms": "fever and stiff neck", "age_years": 8}'

    EMERGENCY = ["chest pain", "difficulty breathing", "shortness of breath", "unconscious", "seizure",
                 "stiff neck", "stroke", "slurred speech", "severe bleeding", "anaphylaxis", "suicidal"]
    URGENT = ["high fever", "persistent vomiting", "dehydration", "blood in", "severe pain", "fever for 3 days"]

    def execute(self, symptoms, age_years=None):
        text = str(symptoms).lower()
        em = [k for k in self.EMERGENCY if k in text]
        ur = [k for k in self.URGENT if k in text]
        if age_years not in (None, "") and float(age_years) < 1 and "fever" in text:
            em.append("fever in infant under 1 year")
        level = "emergency" if em else "urgent" if ur else "routine"
        advice = {"emergency": "Seek emergency care immediately.",
                  "urgent": "See a clinician within 24 hours.",
                  "routine": "Self-care and monitoring are reasonable; see a clinician if worsening."}[level]
        return {"urgency": level, "red_flags": em + ur, "advice": advice, "disclaimer": DISCLAIMER}

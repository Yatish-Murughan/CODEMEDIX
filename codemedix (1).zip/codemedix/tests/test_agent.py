"""Offline tests (no API key). Run: python -m unittest discover tests"""
import json
import subprocess
import sys
import unittest

from agent.core import AgentExecutor, parse_json
from tools import build_tools


class Scripted:
    def __init__(self, replies):
        self.replies = list(replies)

    def generate(self, system, messages):
        return self.replies.pop(0) if self.replies else '{"final_answer": "done"}'


class AgentTests(unittest.TestCase):
    def test_parse_json_handles_fences(self):
        self.assertEqual(parse_json('text ```json\n{"a": 1}\n``` more'), {"a": 1})

    def test_tool_call_then_final(self):
        llm = Scripted(['{"thought":"t","action":"read_file","args":{"filename":"patients.csv"}}',
                        '{"thought":"t","final_answer":"P4 on warfarin"}'])
        answer, trace = AgentExecutor(llm, build_tools()).run("q")
        self.assertEqual(answer, "P4 on warfarin")
        self.assertEqual(trace[0]["tool"], "read_file")
        self.assertIn("Arjun", trace[0]["observation"])

    def test_tool_error_becomes_observation(self):
        llm = Scripted(['{"action":"read_file","args":{"filename":"nope.csv"}}', '{"final_answer":"x"}'])
        _, trace = AgentExecutor(llm, build_tools()).run("q")
        self.assertTrue(trace[0]["observation"].startswith("ERROR"))

    def test_iteration_cap(self):
        llm = Scripted(['{"action":"list_files","args":{}}'] * 20)
        answer, trace = AgentExecutor(llm, build_tools(), max_iterations=3).run("q")
        self.assertLessEqual(len(trace), 3)

    def test_sql_and_calculator(self):
        t = build_tools()
        self.assertIn("Ravi", t["sql_query"].execute(filename="patients.csv", sql="SELECT name FROM data WHERE age > 60"))
        self.assertEqual(t["calculator"].execute(expression="2+2*10"), 22)

    def test_dose_calculator(self):
        d = build_tools()["dose_calculator"].execute(drug="paracetamol", weight_kg=25, age_years=8)
        self.assertEqual(d["single_dose_mg"], 375.0)
        self.assertEqual(d["daily_total_mg"], 1500.0)
        big = build_tools()["dose_calculator"].execute(drug="paracetamol", weight_kg=80, proposed_daily_mg=6000)
        self.assertEqual(big["single_dose_mg"], 1000.0)
        self.assertTrue(any("UNSAFE" in w for w in big["warnings"]))
        self.assertTrue(build_tools()["dose_calculator"].execute(drug="mystery", weight_kg=10).startswith("ERROR"))

    def test_interactions_and_allergy(self):
        r = build_tools()["interaction_checker"].execute(drugs=["ibuprofen", "warfarin", "amoxicillin"], allergies=["penicillin"])
        self.assertEqual(r["interactions"][0]["severity"], "major")
        self.assertTrue(r["allergy_flags"])

    def test_triage(self):
        t = build_tools()["symptom_triage"]
        self.assertEqual(t.execute(symptoms="chest pain since morning")["urgency"], "emergency")
        self.assertEqual(t.execute(symptoms="mild cough")["urgency"], "routine")

    def test_cli_contract(self):
        out = subprocess.run([sys.executable, "main.py", "--json", "--dry-run", "hi"], capture_output=True, text=True)
        d = json.loads(out.stdout.strip().splitlines()[-1])
        self.assertTrue(d["answer"] and len(d["trace"]) >= 2)


if __name__ == "__main__":
    unittest.main()
